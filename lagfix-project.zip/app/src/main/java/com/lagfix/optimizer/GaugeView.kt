package com.lagfix.optimizer

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.view.View

class GaugeView(context: Context) : View(context) {

    private var bigText = ""
    private var smallText = ""
    private var shown = 0f

    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        color = Color.parseColor("#1E293B")
    }
    private val arcPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val bigPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
    }
    private val smallPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#94A3B8")
        textAlign = Paint.Align.CENTER
    }
    private val rect = RectF()

    fun update(percent: Int, big: String, small: String) {
        bigText = big
        smallText = small
        val target = percent.coerceIn(0, 100).toFloat()
        val anim = ValueAnimator.ofFloat(shown, target)
        anim.duration = 700L
        anim.addUpdateListener {
            shown = it.animatedValue as Float
            invalidate()
        }
        anim.start()
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val size = minOf(w, h)
        val sw = size * 0.085f
        trackPaint.strokeWidth = sw
        arcPaint.strokeWidth = sw
        val half = size / 2f - sw
        rect.set(w / 2f - half, h / 2f - half, w / 2f + half, h / 2f + half)

        canvas.drawArc(rect, 135f, 270f, false, trackPaint)
        arcPaint.color = when {
            shown >= 85f -> Color.parseColor("#F87171")
            shown >= 70f -> Color.parseColor("#FBBF24")
            else -> Color.parseColor("#22D3EE")
        }
        canvas.drawArc(rect, 135f, 270f * shown / 100f, false, arcPaint)

        bigPaint.textSize = size * 0.22f
        smallPaint.textSize = size * 0.075f
        val baseY = h / 2f + bigPaint.textSize * 0.2f
        canvas.drawText(bigText, w / 2f, baseY, bigPaint)
        canvas.drawText(smallText, w / 2f, baseY + smallPaint.textSize * 1.6f, smallPaint)
    }
}
